import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const inputRoot=path.resolve(process.argv[2]??'input_data');
const outputRoot=path.resolve(process.argv[3]??'output');
const tempRoot=`${outputRoot}.building`;
const requiredFiles=['room_members.csv','receipt_log.csv','moderation_rules.json'];

function assert(condition,message){if(!condition)throw new Error(message);}
function csvCell(value){const text=String(value??'');return /[",\r\n]/.test(text)?`"${text.replaceAll('"','""')}"`:text;}
function toCsv(headers,rows){return `${headers.join(',')}\n${rows.map(row=>headers.map(header=>csvCell(row[header])).join(',')).join('\n')}\n`;}
function parseCsv(text){
  const rows=[];let row=[];let cell='';let quoted=false;
  for(let index=0;index<text.length;index+=1){
    const char=text[index];
    if(quoted){if(char==='"'&&text[index+1]==='"'){cell+='"';index+=1;}else if(char==='"')quoted=false;else cell+=char;}
    else if(char==='"')quoted=true;
    else if(char===','){row.push(cell);cell='';}
    else if(char==='\n'){row.push(cell.replace(/\r$/,''));if(row.some(value=>value!==''))rows.push(row);row=[];cell='';}
    else cell+=char;
  }
  if(cell!==''||row.length){row.push(cell.replace(/\r$/,''));rows.push(row);}
  assert(!quoted,'CSV引号未闭合');
  const headers=rows.shift()??[];
  assert(headers.length>0&&new Set(headers).size===headers.length,'CSV表头无效');
  return rows.map((values,line)=>{assert(values.length===headers.length,`CSV第${line+2}行列数错误`);return Object.fromEntries(headers.map((header,index)=>[header,values[index]]));});
}
function eventSignature(event){return ['room_id','msg_id','logical_seq','revision','event_type','sender_id','server_ts','text'].map(key=>JSON.stringify(event[key])).join('|');}
function eventOrder(a,b){return Number(a.revision)-Number(b.revision)||a.server_ts.localeCompare(b.server_ts)||a.shard_event_id.localeCompare(b.shard_event_id);}
function matchAndReplace(text,rule){
  if(rule.match_type==='literal'){
    assert(typeof rule.pattern==='string'&&rule.pattern.length>0,'literal规则pattern无效');
    const matched=text.includes(rule.pattern);
    return {matched,text:matched?text.split(rule.pattern).join(rule.replacement):text};
  }
  assert(rule.match_type==='regex','未知遮盖规则类型');
  const expression=new RegExp(rule.pattern,'g');
  const matched=expression.test(text);expression.lastIndex=0;
  return {matched,text:matched?text.replace(expression,rule.replacement):text};
}
function applyRules(source,rules){let current=source;const actions=[];for(const rule of rules){const result=matchAndReplace(current,rule);current=result.text;if(result.matched)actions.push(rule);}return {text:current,actions};}

async function main(){
  for(const relative of requiredFiles)await fs.access(path.join(inputRoot,relative));
  const shardRoot=path.join(inputRoot,'shard_messages');
  const shardFiles=(await fs.readdir(shardRoot)).filter(name=>name.endsWith('.jsonl')).sort();
  assert(shardFiles.length>0,'没有JSONL分片');
  const inputSnapshot=new Map();
  for(const relative of [...requiredFiles,...shardFiles.map(name=>`shard_messages/${name}`)])inputSnapshot.set(relative,await fs.readFile(path.join(inputRoot,...relative.split('/')),'utf8'));
  const members=parseCsv(inputSnapshot.get('room_members.csv'));
  const receipts=parseCsv(inputSnapshot.get('receipt_log.csv'));
  const rules=JSON.parse(inputSnapshot.get('moderation_rules.json'));
  assert(Array.isArray(rules)&&rules.length>0,'moderation_rules必须是非空数组');
  const ruleIds=new Set();for(const rule of rules){assert(rule.rule_id&&!ruleIds.has(rule.rule_id),'rule_id为空或重复');ruleIds.add(rule.rule_id);assert(typeof rule.replacement==='string','replacement无效');}

  const memberMap=new Map();const memberKeys=new Set();
  for(const member of members){assert(member.room_id&&member.user_id&&member.role,'成员字段缺失');const key=`${member.room_id}\u0000${member.user_id}`;assert(!memberKeys.has(key),'房间成员重复');memberKeys.add(key);if(!memberMap.has(member.room_id))memberMap.set(member.room_id,[]);memberMap.get(member.room_id).push(member.user_id);}
  for(const users of memberMap.values())users.sort();

  const events=[];
  for(const file of shardFiles){const lines=inputSnapshot.get(`shard_messages/${file}`).split(/\r?\n/).filter(line=>line.trim()!=='');for(let index=0;index<lines.length;index+=1){const event=JSON.parse(lines[index]);for(const key of ['shard_event_id','room_id','msg_id','logical_seq','revision','event_type','sender_id','server_ts','text'])assert(Object.hasOwn(event,key),`${file}:${index+1}缺少${key}`);assert(Number.isInteger(Number(event.logical_seq))&&Number(event.logical_seq)>0,'logical_seq无效');assert(Number.isInteger(Number(event.revision))&&Number(event.revision)>0,'revision无效');assert(['message','edit','delete'].includes(event.event_type),'event_type无效');events.push(event);}}
  assert(new Set(events.map(event=>event.shard_event_id)).size===events.length,'shard_event_id重复');
  const uniqueSignatures=new Set();const uniqueEvents=[];let duplicateSourceEventCount=0;
  for(const event of events){const signature=eventSignature(event);if(uniqueSignatures.has(signature)){duplicateSourceEventCount+=1;continue;}uniqueSignatures.add(signature);uniqueEvents.push(event);}
  const byMessage=new Map();for(const event of uniqueEvents){const key=`${event.room_id}\u0000${event.msg_id}`;if(!byMessage.has(key))byMessage.set(key,[]);byMessage.get(key).push(event);}

  const receiptKeys=new Set();const duplicateReceiptByRoom=new Map();
  for(const receipt of receipts){assert(receipt.room_id&&receipt.msg_id&&receipt.recipient_id&&receipt.receipt_id,'回执字段缺失');assert(receipt.receipt_type==='delivered','只接受delivered回执');const key=`${receipt.room_id}\u0000${receipt.msg_id}\u0000${receipt.recipient_id}`;if(receiptKeys.has(key))duplicateReceiptByRoom.set(receipt.room_id,(duplicateReceiptByRoom.get(receipt.room_id)??0)+1);else receiptKeys.add(key);}

  const editedByRoom=new Map();const deletedByRoom=new Map();const selected=[];const latestByMessage=new Map();
  for(const [businessKey,revisions] of byMessage){revisions.sort(eventOrder);const first=revisions[0];const latest=revisions[revisions.length-1];latestByMessage.set(businessKey,latest);assert(revisions.every(event=>event.room_id===first.room_id&&event.msg_id===first.msg_id&&event.logical_seq===first.logical_seq&&event.sender_id===first.sender_id),'消息版本身份不一致');if(revisions.some(event=>event.event_type==='edit'))editedByRoom.set(latest.room_id,(editedByRoom.get(latest.room_id)??0)+1);if(latest.event_type==='delete'){deletedByRoom.set(latest.room_id,(deletedByRoom.get(latest.room_id)??0)+1);continue;}const membersInRoom=memberMap.get(latest.room_id);assert(membersInRoom?.includes(latest.sender_id),'发送者不在房间成员中');const expectedRecipients=membersInRoom.filter(userId=>userId!==latest.sender_id);const deliveredRecipients=expectedRecipients.filter(userId=>receiptKeys.has(`${latest.room_id}\u0000${latest.msg_id}\u0000${userId}`));const masked=applyRules(latest.text,rules);selected.push({room_id:latest.room_id,logical_seq:Number(latest.logical_seq),msg_id:latest.msg_id,sender_id:latest.sender_id,final_text_masked:masked.text,moderation_flags:masked.actions.map(rule=>rule.rule_id),visible_revision:Number(latest.revision),first_server_ts:first.server_ts,latest_server_ts:latest.server_ts,delivered_count:deliveredRecipients.length,expected_delivery_count:expectedRecipients.length,receipt_status:deliveredRecipients.length===expectedRecipients.length?'complete':'missing_receipts',expected_recipients:expectedRecipients});}
  selected.sort((a,b)=>a.room_id.localeCompare(b.room_id)||a.logical_seq-b.logical_seq||a.msg_id.localeCompare(b.msg_id));
  const transcriptCounters=new Map();const transcripts=selected.map(item=>{const transcriptSeq=(transcriptCounters.get(item.room_id)??0)+1;transcriptCounters.set(item.room_id,transcriptSeq);const {logical_seq,expected_recipients,...business}=item;return {room_id:item.room_id,transcript_seq:transcriptSeq,...business};});

  const moderationActions=[];for(const message of transcripts){for(const ruleId of message.moderation_flags){const rule=rules.find(item=>item.rule_id===ruleId);moderationActions.push({action_id:`MOD-${String(moderationActions.length+1).padStart(3,'0')}`,room_id:message.room_id,msg_id:message.msg_id,rule_id:rule.rule_id,matched_kind:rule.kind,replacement:rule.replacement,final_text_masked:message.final_text_masked});}}
  const receiptGaps=[];for(const item of selected){for(const recipient of item.expected_recipients){if(!receiptKeys.has(`${item.room_id}\u0000${item.msg_id}\u0000${recipient}`))receiptGaps.push({gap_id:`GAP-${String(receiptGaps.length+1).padStart(3,'0')}`,room_id:item.room_id,msg_id:item.msg_id,missing_recipient_id:recipient,expected_delivery_count:item.expected_delivery_count,delivered_count:item.delivered_count,reason:'recipient_receipt_absent'});}}

  const roomOrder=[...memberMap.keys()].sort();const roomSummary=roomOrder.map(roomId=>{const roomMessages=transcripts.filter(item=>item.room_id===roomId);return {room_id:roomId,visible_messages:roomMessages.length,edited_messages:editedByRoom.get(roomId)??0,deleted_messages:deletedByRoom.get(roomId)??0,moderated_messages:roomMessages.filter(item=>item.moderation_flags.length>0).length,expected_receipts:roomMessages.reduce((sum,item)=>sum+item.expected_delivery_count,0),unique_delivered_receipts:roomMessages.reduce((sum,item)=>sum+item.delivered_count,0),missing_receipts:roomMessages.reduce((sum,item)=>sum+item.expected_delivery_count-item.delivered_count,0),duplicate_receipts:duplicateReceiptByRoom.get(roomId)??0};});
  for(const [relative,before] of inputSnapshot){
    const current=await fs.readFile(path.join(inputRoot,...relative.split('/')),'utf8');
    assert(current===before,`输入文件发生变化:${relative}`);
  }

  await fs.rm(tempRoot,{recursive:true,force:true});await fs.mkdir(path.join(tempRoot,'reports'),{recursive:true});await fs.mkdir(path.join(tempRoot,'scripts'),{recursive:true});
  await fs.writeFile(path.join(tempRoot,'reports','room_transcripts.ndjson'),`${transcripts.map(row=>JSON.stringify(row)).join('\n')}\n`);
  await fs.writeFile(path.join(tempRoot,'reports','moderation_actions.csv'),toCsv(['action_id','room_id','msg_id','rule_id','matched_kind','replacement','final_text_masked'],moderationActions));
  await fs.writeFile(path.join(tempRoot,'reports','receipt_gaps.csv'),toCsv(['gap_id','room_id','msg_id','missing_recipient_id','expected_delivery_count','delivered_count','reason'],receiptGaps));
  await fs.writeFile(path.join(tempRoot,'reports','room_summary.csv'),toCsv(['room_id','visible_messages','edited_messages','deleted_messages','moderated_messages','expected_receipts','unique_delivered_receipts','missing_receipts','duplicate_receipts'],roomSummary));
  await fs.copyFile(fileURLToPath(import.meta.url),path.join(tempRoot,'scripts','rebuild_chat_transcripts.mjs'));
  await fs.rm(outputRoot,{recursive:true,force:true});await fs.rename(tempRoot,outputRoot);
}

try{await main();}catch(error){await fs.rm(tempRoot,{recursive:true,force:true});console.error(error.message);process.exitCode=2;}
