import fs from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const inputRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outputRoot = path.resolve(inputRoot, '..', 'output');
const source = path.join(outputRoot, 'scripts', 'rebuild_chat_transcripts.mjs');
const expected = [
  'reports/moderation_actions.csv',
  'reports/receipt_gaps.csv',
  'reports/room_summary.csv',
  'reports/room_transcripts.ndjson',
  'scripts/rebuild_chat_transcripts.mjs',
];

async function listFiles(root, current = '') {
  const entries = await fs.readdir(path.join(root, current), { withFileTypes: true });
  const result = [];
  for (const entry of entries.sort((left, right) => left.name.localeCompare(right.name, 'en'))) {
    const relative = path.join(current, entry.name);
    if (entry.isDirectory()) result.push(...await listFiles(root, relative));
    else result.push(relative.split(path.sep).join('/'));
  }
  return result;
}

async function main() {
  const major = Number(process.versions.node.split('.')[0]);
  if (!Number.isInteger(major) || major < 20) throw new Error(`Node.js20 or newer required, found ${process.version}`);
  const required = [
    'README.md',
    'package.json',
    'moderation_rules.json',
    'receipt_log.csv',
    'room_members.csv',
    'shard_messages/shard_a.jsonl',
    'shard_messages/shard_b.jsonl',
    'shard_messages/shard_c.jsonl',
    'starter/rebuild_chat_transcripts.mjs',
  ];
  const missing = [];
  for (const relative of required) {
    try { await fs.access(path.join(inputRoot, ...relative.split('/'))); } catch { missing.push(relative); }
  }
  if (missing.length) throw Object.assign(new Error(`missing inputs:${missing.join(',')}`), { exitCode: 2 });
  try { await fs.access(source); } catch { throw Object.assign(new Error('missing completed program:output/scripts/rebuild_chat_transcripts.mjs'), { exitCode: 2 }); }
  await fs.rm(path.join(outputRoot, 'reports'), { recursive: true, force: true });
  const execution = spawnSync(process.execPath, [source, inputRoot, outputRoot], { cwd: inputRoot, encoding: 'utf8', windowsHide: true, timeout: 30000 });
  if (execution.error) throw new Error(`chat audit process error:${execution.error.message}`);
  if (execution.status !== 0) throw new Error(`chat audit process failed:${execution.stderr || execution.stdout}`);
  const actual = await listFiles(outputRoot);
  if (JSON.stringify(actual) !== JSON.stringify(expected)) throw new Error(`output boundary mismatch:${actual.join(',')}`);
  process.stdout.write(execution.stdout);
}

try { await main(); }
catch (error) {
  await fs.rm(path.join(outputRoot, 'reports'), { recursive: true, force: true });
  console.error(error.message || String(error));
  process.exit(Number.isInteger(error.exitCode) ? error.exitCode : 1);
}
